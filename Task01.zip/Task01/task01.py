import csv
import random

# Load the dataset
def load_dataset(file_path):
    dataset = []
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            dataset.append(row)
    return dataset

# Data Preprocessing
def preprocess_dataset(dataset):
    # Remove missing values
    dataset = [row for row in dataset if all(row)]
    return dataset

# Encode categorical labels
def encode_labels(labels):
    label_map = {label: idx for idx, label in enumerate(set(labels))}
    encoded_labels = [label_map[label] for label in labels]
    return encoded_labels


# Split features and labels
def split_features_labels(dataset):
    features = []
    labels = []
    for row in dataset:
        numeric_features = []
        for val in row[:-1]:
            # Try converting to float, if not, treat as categorical label
            try:
                numeric_features.append(float(val))
            except ValueError:
                labels.append(val)
        features.append(numeric_features)
    return features, labels




# Split dataset into training and testing sets
def split_train_test(features, labels, test_ratio=0.2):
    data = list(zip(features, labels))
    random.shuffle(data)
    split_index = int(len(data) * (1 - test_ratio))
    train_data = data[:split_index]
    test_data = data[split_index:]
    train_features, train_labels = zip(*train_data)
    test_features, test_labels = zip(*test_data)
    return train_features, test_features, train_labels, test_labels

class DecisionTreeClassifier:
    def fit(self, X, y):
        self.X = X
        self.y = y
    
    def predict(self, features):
        predictions = []
        for feature in features:
            # Dummy prediction, replace with actual logic
            predictions.append(random.choice(['Wheat', 'Rice', 'Maize']))
        return predictions

# Evaluate accuracy
def accuracy_score(true_labels, predicted_labels):
    correct_predictions = sum(1 for true, pred in zip(true_labels, predicted_labels) if true == pred)
    total_predictions = len(true_labels)
    return correct_predictions / total_predictions


if __name__ == "__main__":
    file_path = "Crop_Dataset.csv"
    
    # Load dataset
    dataset = load_dataset(file_path)

    # Data Preprocessing
    dataset = preprocess_dataset(dataset)

    # Split features and labels
    features, labels = split_features_labels(dataset)

    # Split dataset into training and testing sets
    train_features, test_features, train_labels, test_labels = split_train_test(features, labels)
    
    model = DecisionTreeClassifier()

    model.fit(train_features, train_labels)

    # Print first 5 rows of train and test data
    print("Train Features:", train_features[:5])
    print("\n\nTrain Labels:", train_labels[:5])
    print("\n\nTest Features:", test_features[:5])
    print("\n\nTest Labels:", test_labels[:5])

    # Model Evaluation
    # Predict on testing dataset
    predicted_labels = model.predict(test_features)

    # Evaluate accuracy
    accuracy = accuracy_score(test_labels, predicted_labels)
    print("Accuracy:", accuracy)

    # Example prediction on new environmental conditions
    new_environment = [[25, 60, 6.5, 100, 80, 7.5, 200]]  # Example environmental conditions
    predicted_crop = model.predict(new_environment)
    print("Predicted Crop:", predicted_crop)
